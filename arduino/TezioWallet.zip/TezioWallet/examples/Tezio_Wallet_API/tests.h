#ifndef TESTS_H
#define TESTS_H

void run_op_get_pk_test(TezioWallet_API myWallet, uint8_t curve, uint8_t mode); 
void run_op_sign_and_verify_test(TezioWallet_API myWallet, uint8_t curve, uint8_t mode);


#endif
